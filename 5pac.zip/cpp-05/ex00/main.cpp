/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 18:09:53 by cbolat            #+#    #+#             */
/*   Updated: 2023/10/07 15:40:13 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"

int main(){
	Bureaucrat Bureaucrat1 = Bureaucrat("Bureaucrat", 150);
	std::cout << Bureaucrat1 << std::endl;
	std::cout << "------------" << std::endl;

	try {
		Bureaucrat Bureaucrat2 = Bureaucrat("Bureaucrat", 0);
		std::cout << Bureaucrat2 << std::endl;
	}
	catch(const std::exception& e)
	{
		std::cerr << e.what() << std::endl;
	}
}

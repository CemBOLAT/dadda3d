/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sprites.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/16 13:23:02 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/16 18:37:28 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

static void ft_collec_ani(t_data *data, t_object *c)
{
	double new_frame;

	new_frame = c->frame + COLLECT_FRAME;
	if ((int)new_frame < data->map.collec.frames)
		c->frame = new_frame;
	else
		c->frame = 0;
}

static int	ft_is_in_bound(t_data *data, t_object *temp, int x)
{
	t_coordinates	coord;

	coord.x = (double)temp->x + OFF_SET;
	coord.y = (double)temp->y + OFF_SET;
	if (ft_distance(data->player.pos, coord) < data->map.depth[x])
		return (1);
	return (0);
}

static void	ft_draw_sprite(t_data *data, t_sprite *r, t_img *img, t_object *temp)
{
	int	i;
	int	j;
	int	c;

	i = r->screen.x;
	while (i < r->screen.x + r->sprite.width && i < WIDTH)
	{
		j = r->screen.y;
		while (i >= 0 && j < r->screen.y + r->sprite.height && j < HEIGHT
			&& ft_is_in_bound(data, temp, i))
		{
			r->textures.x = (i - r->screen.x) * (img->width / r->sprite.width);
			r->textures.y = (j - r->screen.y) * (img->height / r->sprite.height);
			if (j >= 0 && r->textures.x >= 0 && r->textures.x < img->width
				&& r->textures.y >= 0 && r->textures.y < img->height)
			{
				c = img->get_addr[(int)r->textures.y * img->width + (int)r->textures.x];
				if (c != ft_create_color(255, 0, 0, 0))
					data->mlx.img.get_addr[j * WIDTH + i] = c;
			}
			j++;
		}
		i++;
	}
}

void	ft_sprites(t_data *data)
{
	t_sprite	spr;
	t_list		*head;
	t_object	*temp;
	double		angle;

	head = data->map.ll_collect;
	while (head)
	{
		temp = head->data;
		ft_collec_ani(data, temp);
		spr.collecs.x = (double)temp->x + OFF_SET;
		spr.collecs.y = (double)temp->y + OFF_SET;
		spr.screen.x = data->player.pos.x - spr.collecs.x;
		spr.screen.y = data->player.pos.y - spr.collecs.y;
		// why is dividing by 2? // why is it adding FOV/2? // why is it subtracting sprite width/2? // why is it multiplying by width?
		// the answer is that it is calculating the angle of the sprite relative to the player
		// the angle is calculated by taking the FOV and dividing it by the width of the screen
		// FOV / 2.0 is the angle of the player's FOV divided by 2 because we want the angle of the player's FOV to be the center of the screen
		// isn't is always at the center of screen. why do we need to divide by 2? because we want the angle of the player's FOV to be the center of the screen
		angle = ft_update_radian(data->player.angle, ft_deg_to_rad(FOV / 2.0) - atan2(spr.screen.y, spr.screen.x)); // kalsın
		spr.sprite.height = (HEIGHT / 2) / ft_distance(data->player.pos, spr.collecs); // we are calculating the height of the sprite
		spr.sprite.width = spr.sprite.height; // we are calculating the width of the sprite beacuse the sprite is a square
		spr.screen.x = WIDTH - (angle * WIDTH / ft_deg_to_rad(FOV)) - (spr.sprite.width / 2); // angle * WIDTH / ft_deg_to_rad(FOV) // her bir fov için pixel hesaplıyoruz
		spr.screen.y = HEIGHT / 2;
		ft_draw_sprite(data, &spr, &data->map.collec.img[(int)temp->frame], temp);
		head = head->next;
	}
}
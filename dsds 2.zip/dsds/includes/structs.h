/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   structs.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/12 12:46:51 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/16 15:40:15 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STRUCTS_H
# define STRUCTS_H

typedef struct s_dimen
{
	double	width;
	double	height;
}	t_dimen;

typedef struct s_coordinates
{
	double	x;
	double	y;
}	t_coordinates;

typedef struct s_mini_map
{
	double	x;
	double	y;
	double	radius;
}	t_mini_map;

typedef struct s_object
{
	double	x;
	double	y;
	double	frame;
}	t_object;

typedef struct s_list
{
	void			*data;
	struct s_list	*next;
}	t_list;

typedef struct s_img
{
	void	*img; // konumun mlxi
	int		height; //
	int		width; //
	int		bits_per_pixel; // mlx içine atılır
	int		line_length; // mlx içine atılır
	int		steps; // mlx içine atılır
	int		*get_addr; // günün sonunda mlx_get_data_addr ile alınır
}	t_img;

typedef struct s_i_spr
{
	int		frames;
	t_img	*img;
}	t_i_spr;

typedef struct s_mlx
{
	void	*display_connector;
	void	*win;
	t_img	img;
}	t_mlx;

typedef struct s_render
{
	double			degree; // ısın açısı
	double			angle; // karakter açısı
	t_coordinates	wall_hit;
	t_dimen			wall_dimen;
	double			distance;
	int				direction;
	double			wall_height;
	int				y_tex;
}	t_render;

typedef struct s_sprite
{
	t_coordinates	screen;
	t_coordinates	collecs;
	t_coordinates	textures;
	t_dimen			sprite;
}	t_sprite;

typedef struct s_player
{
	t_coordinates			pos; // konum
	t_coordinates			dir; // gidiş yönü
	t_coordinates			move; // hareket
	double					angle; // açı
	double					rotate; // 0 ise dönmez 1 ise döner
}	t_player;

typedef struct s_map
{
	t_img			north;
	t_img			south;
	t_img			west;
	t_img			east;
	t_i_spr			door;
	t_i_spr			collec;
	t_list			*ll_door;
	t_list			*ll_collect;
	char			**map;
	int				ceiling_c;
	int				floor_c;
	double			depth[WIDTH]; // derinlik arrayi neden 1024 çünkü 1024 tane çizgi var
	t_coordinates	sprite; // sprite konumu // ihtiyaç yok
}	t_map;

typedef struct s_data
{
	t_mlx			mlx;
	t_player		player;
	t_map			map;
}	t_data;

#endif

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/11 20:40:59 by cbolat            #+#    #+#             */
/*   Updated: 2023/09/22 12:54:34 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "DiamondTrap.hpp"

int main(){
	DiamondTrap diamond("DiamondTrap");

	diamond.attack("target");

	diamond.takeDamage(10);
	diamond.takeDamage(10);
	
	return (0);
}

#ifndef CHESS_HPP

#define CHESS_HPP

#include "Board.hpp"
#include "Pieces.hpp"
#include <string>
using namespace std;

class Pieces;
class Board;

class Chess {
	public:
		// Big Three + Constructor
		Chess();
		Chess(const Chess &c);
		Chess &operator=(const Chess &c);
		~Chess();

		// **************** Setters and Getters ****************
		inline Board	getBoard() const { return (_board); }
		inline void		setBoard(Board board) { _board = board; }
		inline bool		getIsWhiteTurn() const { return (_isWhiteTurn); }
		inline void		setIsWhiteTurn(bool isWhiteTurn) { _isWhiteTurn = isWhiteTurn; }
		inline bool		getIsCheck() const { return (_isCheck); }
		inline void		setIsCheck(bool isCheck) { _isCheck = isCheck; }
		inline bool		getIsCheckMate() const { return (_isCheckMate); }
		inline void		setIsCheckMate(bool isCheckMate) { _isCheckMate = isCheckMate; }
		// ****************************************************************
		// ****************Input Control Functions****************
		string			getInput(char color) const;
		bool			isOccupied(const vector<int> &input, char c) const;
		bool			isSpecialMove(string input, char color) const;
		bool			isValidInput(string input, char c) const;
		bool			isInputsLetterValid(string input) const;
		bool			isCastling(string input, char color) const;
		bool			isValidMove(const vector<int> &a, char c) const;
		bool			isPromotion(string input, char color) const;
		// ****************************************************************
		// *************************Special Moves*******************
		void			loadGame(bool &_isWhiteTurn);
		void			saveGame(const bool &isW) const;
		// ****************************************************************
		// ****************Move Control Functions****************
		bool			isCheckedAfterMove(const string &input, char c) const;
		bool			isCheck(const string &enemyKingCoordinate, char color, const Board &tempBoard) const;
		string			getKingCoordinate(char color) const;
		bool			isCheckMate(const string &enemyKingCoordinate, char enemyColor) const ;
		bool			isSteelMate(char c) const;
		bool			isSteelMateNoMoves(char color) const;
		bool			isSteelMateOnPieces(char color) const;
		void			makeCastling(const string &input, char color);
		vector<string>	getWholeValidMoves(char color) const;
		// ****************************************************************
		// *************************AI Functions*******************
		void			suggestMove(char c, char suggest, Board &b) const;
		double			getTotalPoint(char c, const Board &board) const;
		string			getSuggestRecur(char playerColor, char enemyColor, int depth, Board &b) const;
		//bool			isCheckMatedAfterMove(const string &input, char color, const string &enemyKingCoordinate) const;
		// ****************************************************************
		// Member Functions
		void			run();
		void			takeMove(char color, char enemyColor, bool &_isWhiteTurn);
	private:
		Board	_board;
		bool	_isWhiteTurn;
		bool	_isCheck;
		bool	_isCheckMate;
};

#endif

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/13 17:38:11 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/13 17:45:49 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MAP_H
# define MAP_H

# define EMPTY_SPACE '0'
# define WALL '1'
# define CLOSED_DOOR '2'
# define WALLS "12"
# define OPENED_DOOR '3'
# define DOORS "23"
# define PLAYER_N 'N'
# define PLAYER_S 'S'
# define PLAYER_E 'E'
# define PLAYER_W 'W'
# define COLLECS 'C'

#endif

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_door_sprite.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/12 14:37:01 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/12 14:39:57 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

void	ft_door_sprite(t_data *data)
{
	t_list		*temp;
	t_list		*next;
	t_object	*door;
	double		new_frame;

	temp = data->map.ll_door;
	while (temp)
	{
		door = (t_object *)temp->data;
		if (data->map.map[(int)door->y][(int)door->x] == OPENED_DOOR)
			new_frame = door->frame + DOOR_FRAME;
		else
			new_frame = door->frame - DOOR_FRAME;
		if ((int)new_frame < data->map.door.frames)
			door->frame = new_frame;
		if (door->frame <= 0)
		{
			next = temp->next;
			ft_ll_remove(&data->map.ll_door, door->y, door->x);
			temp = next;
		}
		else
			temp = temp->next;
	}
}

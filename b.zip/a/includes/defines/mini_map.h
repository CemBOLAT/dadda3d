/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_map.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/13 17:45:33 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/13 19:03:56 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINI_MAP_H
# define MINI_MAP_H

# define BORDER 10
# define RADIUS 60
# define CENTER 70
# define MAP_FOV 10
# define MAP_EDGE_L 12
# define PLAYER_R 3

#endif

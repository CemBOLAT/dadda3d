/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_update.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/09 14:13:14 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/12 14:40:31 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

static	t_mini_map ft_fill_mini_map_comp(int x, int y, int radius)
{
	t_mini_map	mini_map;

	mini_map.x = x;
	mini_map.y = y;
	mini_map.radius = radius;
	return (mini_map);
}

// dikkat hata olabilir burda
static int	ft_is_in_map_bound(t_mini_map map, int x, int y)
{
	double	dist_to_center;

	dist_to_center = sqrt(pow(x - map.x, 2) + pow(y - map.y, 2));
	if (dist_to_center <= map.radius && dist_to_center >= map.radius)
		return (1);
	if (dist_to_center <= map.radius)
		return (2);
	return (0);
}

static void	ft_draw_circle(int	*data, t_mini_map map, int color)
{
	int	border;
	int	cord[2];

	border = CENTER - map.radius;
	cord[0] = border;
	while (cord[0] <= border + (map.radius * 2))
	{
		cord[1] = border;
		while (cord[1] <= border + (map.radius * 2))
		{
			if (ft_is_in_map_bound(map, cord[1], cord[0]))
				data[cord[0] * WIDTH + cord[1]] = color;
			cord[1]++;
		}
		cord[0]++;
	}
}

static void ft_draw_square_comp(int *data,int color, t_coordinates cords, t_mini_map map)
{
	int	x;
	int	y;

	y = cords.y;
	while (y < cords.y + MAP_EDGE_L)
	{
		x = cords.x;
		while (x < cords.x + MAP_EDGE_L)
		{
			if (ft_is_in_map_bound(map, x, y))
				data[y * WIDTH + x] = color;
			x++;
		}
		y++;
	}
}

static void	ft_draw_comps(t_data *data, t_mini_map map)
{
	t_coordinates	cords;
	int				index[2];

	if (data->player.pos.y - (MAP_FOV / 2) > 0)
		index[0] = data->player.pos.y - (MAP_FOV / 2);
	else
		index[0] = 0;
	while (data->map.map[index[0]] && index[0] <= data->player.pos.y + (MAP_FOV / 2))
	{
		if (data->player.pos.x - (MAP_FOV / 2) > 0)
			index[1] = data->player.pos.x - (MAP_FOV / 2);
		else
			index[1] = 0;
		while (data->map.map[index[0]][index[1]] && index[1] <= data->player.pos.x + (MAP_FOV / 2))
		{
			cords.y = (index[0] * MAP_EDGE_L) - (data->player.pos.y * MAP_EDGE_L) + CENTER;
			cords.x = (index[1] * MAP_EDGE_L) - (data->player.pos.y * MAP_EDGE_L) + CENTER;
			if (data->map.map[index[0]][index[1]] == CLOSED_DOOR)
				ft_draw_square_comp(data->mlx.img.get_addr, ft_create_color(0, 160, 40, 20), cords, map);
			else if (!ft_strchr("03NSEWC", data->map.map[index[0]][index[1]]))
				ft_draw_square_comp(data->mlx.img.get_addr, ft_create_color(0, 60, 60, 60), cords, map);
			index[1]++;
		}
		index[0]++;
	}
}

static void	ft_render_mini_map(t_data *data)
{
	t_mini_map	mini_map;
	t_mini_map	player;

	mini_map = ft_fill_mini_map_comp(CENTER, CENTER, RADIUS);
	player = ft_fill_mini_map_comp(CENTER, CENTER, PLAYER_R);

	ft_draw_circle(data->mlx.img.get_addr, mini_map, ft_create_color(0, 255, 255, 255));
	ft_draw_circle(data->mlx.img.get_addr, player, ft_create_color(0, 255, 0, 0));
	ft_draw_comps(data, mini_map);
	//ft_draw_rays(data, mini_map);
}

int	ft_update(t_data *data)
{
	ft_move_player(data);
	//ft_door_sprite(data);
	ft_render(data);
	ft_render_mini_map(data);
	mlx_clear_window(data->mlx.display_connector, data->mlx.win);
	mlx_put_image_to_window(data->mlx.display_connector, data->mlx.win, data->mlx.img.img, 0, 0);
	return (0);
}

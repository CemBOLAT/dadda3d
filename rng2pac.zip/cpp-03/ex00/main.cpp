#include "ClapTrap.hpp"

/*
int main(){
	ClapTrap clap("Clap");

	clap.attack("Clap1");
	clap.attack("Clap2");
	clap.attack("Clap3");
	clap.attack("Clap4");
	clap.attack("Clap5");
	clap.beRepaired(5);
	clap.beRepaired(5);
	clap.beRepaired(5);
	clap.beRepaired(5);
	clap.beRepaired(5);
	clap.beRepaired(5);
	clap.attack("Clap6");

	std::cout << "NAME : " << clap.getName() << std::endl;
	std::cout << "HP : " << clap.getHitPoint() << std::endl;
	std::cout << "EP : " << clap.getEnergyPoint() << std::endl;
	std::cout << "AD : " << clap.getAttackDamage() << std::endl;

	return (0);
}*/

int main(){
	ClapTrap clap("Clap");

	clap.attack("Clap1");
	clap.takeDamage(5);
	clap.takeDamage(6);
	clap.takeDamage(6);
	clap.attack("Clap2");

	std::cout << "NAME : " << clap.getName() << std::endl;
	std::cout << "HP : " << clap.getHitPoint() << std::endl;
	std::cout << "EP : " << clap.getEnergyPoint() << std::endl;
	std::cout << "AD : " << clap.getAttackDamage() << std::endl;
}

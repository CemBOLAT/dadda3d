#include "../header/Chess.hpp"

// Post Condition: Runs the game
int	main(void)
{
	Chess	chess;
	int	input;
	do {
		cout << "Welcome to HW01 made by Cemal BOLAT 210104004010 " << endl;
		cout << "1. Game" << endl;
		cout << "2. Options" << endl;
		cout << "3. Exit" << endl;
		cout << "----> ";
		cin >> input;
		cin.ignore();
	} while (input < 1 || input > 3);

	if (input == 1){
		chess.run();
	}
	else if (input == 2){
		cout << "Here is explanation of special moves ." << endl;
		cout << "1. Saving : Typing 'save' is enough for saving board to .txt file at ./Board folder\n\
after typing 'save' program will prompt you to enter name of .txt file.\n" << endl;
		cout << "2. Loading : Typing 'load' is enough to start loading section.\n \
After typing load program will prompt you to enter name of .txt file\n" << endl;
		cout << "3. Suggestion : Typing 'suggest' is enough to get the\
best move on the board according to point.\n" << endl;
		cout << "4. Castling : Typing 'O-O-O' or 'O-O' enough for CASTLING\n" << endl;
		string	input;

		cout <<	"Press any key to continue..." << endl;
		getline(cin, input);

		chess.run();
	}
	else if (input == 3){
		cout << "GoodBYE !" << endl;
	}

	return (0);
}

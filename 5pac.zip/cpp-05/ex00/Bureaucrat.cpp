/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 17:54:56 by cbolat            #+#    #+#             */
/*   Updated: 2023/09/17 20:01:15 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"

Bureaucrat::Bureaucrat()
{
	std::cout << "Bureaucrat default constructor called" << std::endl;
}

Bureaucrat::Bureaucrat(std::string name, int grade)
{
	const_cast<std::string &> (this->name) = name;
	this->grade = grade;
	if (grade < HIGHEST_GRADE)
		throw Bureaucrat::GradeTooHighException();
	else if (grade > LOWEST_GRADE)
		throw Bureaucrat::GradeTooLowException();
	std::cout << "Bureaucrat " << this->name << " is created ! " << std::endl;
}

Bureaucrat::Bureaucrat(Bureaucrat const &obj){
	*this = obj;
	std::cout << "Bureaucrat copy constructor called" << std::endl;
}

Bureaucrat &Bureaucrat::operator=(Bureaucrat const &obj) {
	const_cast<std::string&>(this->name) = obj.name;
	this->grade = obj.grade;
	std::cout << "Bureaucrat assignation operator called" << std::endl;
	return (*this);
}

Bureaucrat::~Bureaucrat(){
	std::cout << "Bureaucrat " << this->name << " is dead" << std::endl;
}

std::string const	Bureaucrat::getName() const
{
	return (this->name);
}

int					Bureaucrat::getGrade() const
{
	return (this->grade);
}

void				Bureaucrat::incrementGrade(int grade)
{
	if (this->grade - grade < HIGHEST_GRADE)
		throw Bureaucrat::GradeTooHighException();
	else
		this->grade -= grade;
}

void				Bureaucrat::decrementGrade(int grade)
{
	if (this->grade + grade > LOWEST_GRADE)
		throw Bureaucrat::GradeTooLowException();
	else
		this->grade += grade;
}

std::ostream &operator<<(std::ostream &out, Bureaucrat const &Bureaucrat)
{
	out << Bureaucrat.getName() << ", Bureaucrat grade " << Bureaucrat.getGrade();
	return (out);
}

const char *Bureaucrat::GradeTooHighException::what() const throw()
{
	return ("Grade is too high");
}

const char *Bureaucrat::GradeTooLowException::what() const throw()
{
	return ("Grade is too low");
}

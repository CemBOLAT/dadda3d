/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Form.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/17 19:12:04 by cbolat            #+#    #+#             */
/*   Updated: 2023/09/17 20:28:39 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Form.hpp"

Form::Form() : name("default"), gradeToSign(150), gradeToExecute(150) {
	std::cout << "Form default constructor called" << std::endl;
	this->isSigned = false;
}

Form::~Form() {
	std::cout << "Form destructor called" << std::endl;
}

Form::Form(const Form &obj) : name(obj.name), gradeToSign(obj.gradeToSign), gradeToExecute(obj.gradeToExecute) {
	std::cout << "Form copy constructor called" << std::endl;
	this->isSigned = obj.isSigned;
}

Form	&Form::operator=(const Form &obj) {
	std::cout << "Form assignation operator called" << std::endl;
	this->isSigned = obj.isSigned;
	return (*this);
}

Form::Form(std::string name, bool isSigned, int gradeToSign, int gradeToExecute)
			: name(name), gradeToSign(gradeToSign), gradeToExecute(gradeToExecute) {
	if (gradeToSign < HIGHEST_GRADE || gradeToExecute < HIGHEST_GRADE)
		throw Form::GradeTooHighException();
	else if (gradeToSign > LOWEST_GRADE || gradeToExecute > LOWEST_GRADE)
		throw Form::GradeTooLowException();
	std::cout << "Form special constructor called" << std::endl;
	this->isSigned = isSigned;
}

std::string	Form::getName() const {
	return (this->name);
}

bool	Form::getIsSigned() const {
	return (this->isSigned);
}

int		Form::getGradeToSign() const {
	return (this->gradeToSign);
}

int		Form::getGradeToExecute() const {
	return (this->gradeToExecute);
}

const char	*Form::GradeTooHighException::what() const throw() {
	return ("Grade is too high");
}

const char	*Form::GradeTooLowException::what() const throw() {
	return ("Grade is too low");
}

std::ostream	&operator<<(std::ostream &out, const Form &obj) {
	out << "Form name: " << obj.getName() << std::endl;
	out << "Form is signed: " << obj.getIsSigned() << std::endl;
	out << "Form grade to sign: " << obj.getGradeToSign() << std::endl;
	out << "Form grade to execute: " << obj.getGradeToExecute() << std::endl;
	return (out);
}

void	Form::beSigned(Bureaucrat &obj){
	if (this->getIsSigned())
		std::cout << this->getName()  << " signed already ! " << std::endl;
	else if (obj.getGrade() > this->gradeToSign)
		throw Form::GradeTooLowException();
	else{
		this->isSigned = true;
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_map.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/13 17:45:33 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/13 19:03:56 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINI_MAP_H
# define MINI_MAP_H

# define BORDER 20
# define RADIUS 120
# define CENTER 140
# define MAP_FOV 20
# define MAP_EDGE_L 24
# define PLAYER_R 6

#endif

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_start_game.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/08 18:16:47 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/13 18:41:52 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

static int	ft_update_movement(t_data *data, int x, int y, int ro)
{
	data->player.move.x = x;
	data->player.move.y = y;
	data->player.rotate = ro;
	return (0);
}

static int	ft_key_press(int k_code, t_data *data)
{
	if (k_code == W) // 13
		ft_update_movement(data, 0, -1, 0);
	else if (k_code == S) // 1
		ft_update_movement(data, 0, 1, 0);
	else if (k_code == A || k_code == LEFT) // 0
		ft_update_movement(data, -1 , 0, 0);
	else if (k_code == D || k_code == RIGHT) // 2
		ft_update_movement(data, 1, 0, 0);
	else if (k_code == Q) // 12
		ft_update_movement(data, 0, 0, -1);
	else if (k_code == E) // 14
		ft_update_movement(data, 0, 0, 1);
	else if (k_code == ESC) // 53
		ft_free_and_exit(data, EXIT_SUCCESS);
	// else if (k_code == F)
	// 	open close door;
	printf("player x: %f\n", data->player.pos.x);
	printf("player y: %f\n", data->player.pos.y);
	printf("key pressed: %d\n", k_code);
	return (0);
}

static int	ft_key_release(int k_code, t_data *data)
{
	if (k_code == W || k_code == S)
		data->player.move.y = 0;
	else if (k_code == A || k_code == D || k_code == RIGHT || k_code == LEFT)
		data->player.move.x = 0;
	else if (k_code == Q || k_code == E)
		data->player.rotate = 0;
	return (0);
}

static int	ft_mouse_rotation(int x, int y, t_data *data)
{
	double	difference;

	(void)y;
	difference = x - (WIDTH / 2);
	data->player.angle = ft_update_radian(data->player.angle,
			(difference / 360.0));
	mlx_mouse_move(data->mlx.win, WIDTH / 2, HEIGHT / 2);
	return (0);
}

int	ft_start_game(t_data *data)
{
	data->mlx.win = (void *)mlx_new_window(data->mlx.display_connector,
			WIDTH, HEIGHT, "cub3d-made by cbolat");
	if (!data->mlx.win)
	{
		printf("Error\nCouldn't open window.\n");
		return (-1);
	}
	data->player.move.x = 0;
	data->player.move.y = 0;
	data->player.rotate = 0;
	mlx_mouse_hide();
	mlx_hook(data->mlx.win, ON_KEYDOWN, NO_MASK, ft_key_press, data);
	mlx_hook(data->mlx.win, ON_KEYUP, NO_MASK, ft_key_release, data);
	mlx_hook(data->mlx.win, ON_MOUSEMOVE, NO_MASK, ft_mouse_rotation, data);
	mlx_hook(data->mlx.win, ON_EXIT, NO_MASK, ft_free_and_exit, data);
	mlx_loop_hook(data->mlx.display_connector, ft_update, data); // burdayız
	mlx_loop(data->mlx.display_connector);
	return (1);
}

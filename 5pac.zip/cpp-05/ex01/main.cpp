/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/15 18:09:53 by cbolat            #+#    #+#             */
/*   Updated: 2023/09/17 20:28:45 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Form.hpp"

int main(){

	try {
		Form Form1 = Form("Form1", false, 150, 150);
		Bureaucrat Bureaucrat1 = Bureaucrat("Cemal Bolat", 5);
		Form1.beSigned(Bureaucrat1);
		Form1.beSigned(Bureaucrat1);
		Bureaucrat1.signForm(Form1.getName(), Form1.getIsSigned());
	}
	catch(const std::exception& e)
	{
		std::cerr << e.what() << std::endl;
	}
}

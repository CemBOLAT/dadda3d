/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sprites.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/16 13:23:02 by cbolat            #+#    #+#             */
/*   Updated: 2023/08/16 15:24:45 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

static void ft_collec_ani(t_data *data, t_object *c)
{
	double new_frame;

	new_frame = c->frame + COLLECT_FRAME;
	if ((int)new_frame < data->map.collec.frames)
		c->frame = new_frame;
	else
		c->frame = 0;
}

static int	ft_is_in_bound(t_data *data, t_object *temp, int x)
{
	t_coordinates	coord;

	coord.x = (double)temp->x + OFF_SET;
	coord.y = (double)temp->y + OFF_SET;
	if (ft_distance(data->player.pos, coord) < data->map.depth[x])
		return (1);
	return (0);
}

static void	ft_draw_sprite(t_data *data, t_sprite *r, t_img *img, t_object *temp)
{
	int	i[3];
	ft_fill_garbage(i, 3);

	i[0] = r->screen.x;
	while (i[0] < r->screen.x + r->sprite.width && i[0] < WIDTH)
	{
		i[1] = r->screen.y;
		while (i[0] >= 0 && i[1] < r->screen.y + r->sprite.height && i[1] < HEIGHT
				&& ft_is_in_bound(data, temp, i[0]))
		{
			r->textures.x = (i[0] - r->screen.x) * (img->width / r->sprite.width);
			r->textures.y = (i[1] - r->screen.y) * (img->height / r->sprite.height);
			if (i[1] >= 0 && r->textures.x >= 0 && r->textures.x < img->width
					&& r->textures.y >= 0 && r->textures.y < img->height)
			{
				i[2] = img->get_addr[(int)r->textures.y * img->width + (int)r->textures.x];
				if (i[2] != ft_create_color(255, 0, 0, 0))
					data->mlx.img.get_addr[i[1] * WIDTH + i[0]] = i[2];
			}
			i[1]++;
		}
		i[0]++;
	}
}

void	ft_sprites(t_data *data)
{
	t_sprite	spr;
	t_list		*head;
	t_object	*temp;
	double		angle;

	head = data->map.ll_collect;
	while (head)
	{
		temp = head->data;
		ft_collec_ani(data, temp);
		spr.collecs.x = temp->x + OFF_SET;
		spr.collecs.y = temp->y + OFF_SET;
		spr.screen.x = data->player.pos.x - spr.collecs.x;
		spr.screen.y = data->player.pos.y - spr.collecs.y;
		angle = ft_update_radian(data->player.angle, ft_deg_to_rad(FOV / 2.0) - atan2(spr.screen.y, spr.screen.x));
		spr.sprite.height = (HEIGHT / 2) / ft_distance(data->player.pos, spr.collecs);
		spr.sprite.width = spr.sprite.height;
		spr.screen.x = WIDTH - (angle * WIDTH / ft_deg_to_rad(FOV) - spr.sprite.width / 2);
		spr.screen.y = HEIGHT / 2;
		ft_draw_sprite(data, &spr, &data->map.collec.img[(int)temp->frame], temp);
		head = head->next;
	}
}
